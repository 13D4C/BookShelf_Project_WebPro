const o=!0;export{o as b};
