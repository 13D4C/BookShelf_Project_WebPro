import{ay as a}from"./BkNIMPUX.js";a();
