import{b as a}from"../chunks/CPiIr9-y.js";export{a as start};
